<?php

// +----+--------------+------------+---------------------+--------+--------+
// | id | keyboardBase | switchType | actuation_mechanism | layout | price  |
// +----+--------------+------------+---------------------+--------+--------+

class Keyboard {
    private int $id;
    private string $keyboardBase;
    private string $switchType;
    private string $actuation_mechanism;
    private string $layout;
    private float $price;

    //setters
    public function setId(int $nid){$this->id = $nid;}
    public function setKeyboardBase(string $nKeyboardBase){$this->keyboardBase = $nKeyboardBase;}
    public function setswitchType(string $nswitchType){$this->switchType = $nswitchType;}
    public function setactuation_mechanism(string $nactuation_mechanism){$this->actuation_mechanism = $nactuation_mechanism;}
    public function setlayout(string $nlayout){$this->layout = $nlayout;}
    public function setprice(float $nprice){$this->price = $nprice;}

    //getters
    public function getId(){return $this->id;}
    public function getKeyboardBase(){return $this->keyboardBase;}
    public function getSwitchType(){return $this->switchType;}
    public function getActuationMechanism(){return $this->actuation_mechanism;}
    public function getLayout(){return $this->layout;}
    public function getPrice(){return $this->price;}
}


?>
