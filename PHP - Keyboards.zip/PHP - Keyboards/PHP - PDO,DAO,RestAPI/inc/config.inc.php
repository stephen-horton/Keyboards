<?php

//database connectivity
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'week8');

define('API_URL', 'http://localhost/week8practice-sho-62/RestAPI.php'); 