<?php

class Validation{
    //this functions validates the add keyboard form
    static function validateAddKeyboard(Array $postData){
        //store the arrors in an array
        $errors = array();

        //validate the keyboard base
        $validBaseTypes = array("test","ABS", "PBT", "Aluminium");//first one doesnt work ehre for some reason

        //check if its a string
        if(isset($postData["keyboardBase"]) && is_string($postData["keyboardBase"]) && !array_search($postData["keyboardBase"], $validBaseTypes)){

            //check if it is a valid base type
            // $errors[] = "Please specify a valid keyboard base.";

            // if(!array_search($postData["keyboardBase"], $validBaseTypes))
            $errors[] = "The keyboard base " . $postData["keyboardBase"]. " is not valid.";
        }

        //validate the switchtype
        $validSwitchTypeTypes = array ("default", "optical","membrane","topre"); //first one deosnt work still
        //check if its a string
        if(isset($postData["switchType"]) && is_string($postData["switchType"]) && !array_search($postData["switchType"], $validSwitchTypeTypes)){
            //check if it is a valid base type
            // $errors[] = "Please specify a valid keyboard base.";
            if(!array_search($postData["switchType"], $validSwitchTypeTypes))
            $errors[] = "The switch type " . $postData["switchType"] . " is not valid.";
        }

        //validate actuation mechanism
        $valideActuationMechanismTypes = array ("default", "tactile","linear","clicky");
        //chekc if its a string
        if(isset($postData["actuationMechanism"]) && is_string($postData["actuationMechanism"]) && !array_search($postData["actuationMechanism"], $valideActuationMechanismTypes)){
            //check if it is a valid base type
            // $errors[] = "Please specify a valid keyboard base.";
            if(!array_search($postData["actuationMechanism"], $valideActuationMechanismTypes))
            $errors[] = "The actuation mechnism " . $postData["actuationMechanism"] . " is not valid.";
        }

        //validate the layout
        $validLayoutTypes = array(0, 75, 40, 60, 108);
        if(isset($postData["layout"]) && is_string($postData["layout"]) && !array_search($postData["layout"], $validLayoutTypes)){
            //check if it is a valid base type
            // $errors[] = "Please specify a valid keyboard base.";
            if(!array_search($postData["layout"], $validLayoutTypes))
            $errors[] = "The layout " . $postData["layout"] . " is not valid.";
        }

        //validate the price
        if(!filter_var($postData["price"], FILTER_VALIDATE_FLOAT)){ 
            $errors[] = "Please enter a valid price in the format X.XX";
        }
        if($postData["price"] < 20.00){
            $errors[] = "Price is too low.";
        }



        return $errors;
    }



    
}
?>