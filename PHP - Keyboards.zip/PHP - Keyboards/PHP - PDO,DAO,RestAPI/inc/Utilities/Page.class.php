<?php

class Page{

    private static string $title = "Keyboards";

    static function header(){ ?>
    <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title><?php echo self::$title ?></title>
  </head>
  <body>
    <div class="container">
    <h1><?php echo self::$title ?></h1>



    <?php }

    static function footer(){?>
    
        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
        -->
    </body>
    </html>
    <?php }

// +----+--------------+------------+---------------------+--------+--------+
// | id | keyboardBase | switchType | actuation_mechanism | layout | price  |
// +----+--------------+------------+---------------------+--------+--------+
// |  1 | PBT          | optical    | tactile             | 75     | 119.57 |


static function showKeyboards(Array $keyboards){ ?>

  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Id</th>
        <th scope="col">keyboardBase</th>
        <th scope="col">switchType</th>
        <th scope="col">actuation_mechanism</th>
        <th scope="col">layout</th>
        <th scope="col">price</th>
      </tr>
    </thead>
  <tbody>

  <?php
  foreach($keyboards as $k){
    echo '<tr>';
    echo '<td scope="col">'.$k->getId(). '</td>';
    echo '<td scope="col">'.$k->getKeyboardbase().'</td>';
    echo '<td scope="col">'.$k->getSwitchType().'</td>';
    echo '<td scope="col">'.$k->getActuationMechanism() . '</td>';
    echo '<td scope="col">'.$k->getLayout().'</td>';
    echo '<td scope="col">'.$k->getPrice().'</td>';
    echo '<td scope="col"><a href="?action=delete&idToDelete='.$k->getId().'"><button class="btn btn-danger">Delete</button></a></td></tr>';

  }
  ?>

<?php }

public static function KeyboardForm(){ ?>

<form method="POST" action ="">
  <input type="hidden" name="action" value= "create">
  <div class="row">
    <div class="mb-3">keyboardBase
      <input type="text" class="form-control" name="keyboardBase" placeholder="type keyboard base here">
    </div>
  </div>

  <div class="row">
    <div class="mb-3">switchType
      <input type="text" class="form-control" name="switchType" placeholder="Tactile">
    </div>
  </div>

  <div class="row">
    <div class="mb-3">actuationMechanism
      <input type="text" class="form-control" name="actuationMechanism" placeholder="Mechanical">
    </div>
  </div>

  <div class="row">
    <div class="mb-3">Layout
      <input type="text" class="form-control" name="layout" placeholder="40">
    </div>
  </div>

  <div class="row">
    <div class="mb-3"> Price
      <input type="text" class="form-control" name="price" placeholder="20.00">
    </div>
  </div>

  <div class="row">
    <div class="mb-3">
      <input type="submit" value="Add keyboard">
    </div>
  </div>
</form>


<?php }

public static function showWarning($message){ ?>
  <div class="alert alert-warning"><?php echo $message; ?></div>
<?php }

static function showValidationErrors($errors){ ?>
  <div class="alert alert-danger">
    <?php echo "<ul>";

    foreach($errors as $err){
      echo "<li>" . $err . "</li>";
    }
    echo "</ul>";
    ?>
    </div>

<?php }


}

?>