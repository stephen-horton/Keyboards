<?php

class RestClient {

static function call($method, $callData)    {
    //State the type of call
    $requestHeader = array('requesttype' => $method);

    //Combine data with request header
    $streamData = array_merge($requestHeader, $callData);

    $options = array(
        'http' => array(
            'header' => "Content-Type: application/json\r\n",
            'method' => $method,
            'content' => json_encode($streamData)
        )
        );

    $context = stream_context_create($options);
    $result = file_get_contents(API_URL, false, $context);

    return $result;

}

}