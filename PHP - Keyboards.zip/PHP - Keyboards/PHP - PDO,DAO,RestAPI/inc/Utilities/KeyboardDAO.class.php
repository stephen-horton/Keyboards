<?php

class KeyboardDAO{

    private static $_db;

    static function initialize(){
        self::$_db = new PDOService("Keyboard");

    }

    static function getKeyboards(){
        $sql = "SELECT * FROM keyboards";

        self::$_db->query($sql);
        self::$_db->execute();
        return self::$_db->resultSet();
    }

    static function deleteKeyboard(int $idToDelete){
        $sql = "DELETE FROM keyboards WHERE id = :id";
        self::$_db->query($sql);
        self::$_db->bind(":id", $idToDelete);
        self::$_db->execute();
        return self::$_db->rowCount();
    }

    static function addKeyboard(Keyboard $newKeyboard){
        $sql = "INSERT INTO keyboards (keyboardbase, switchtype, actuation_mechanism,layout, price)
        VALUES (:keyboardbase,:switchType,:actuationMechanism, :layout, :price)";

        self::$_db->query($sql);
        self::$_db->bind(":keyboardbase", $newKeyboard->getKeyboardBase());
        self::$_db->bind(":switchType", $newKeyboard->getSwitchType());
        self::$_db->bind(":actuationMechanism", $newKeyboard->getActuationMechanism());
        self::$_db->bind(":layout", $newKeyboard->getLayout());
        self::$_db->bind(":price", $newKeyboard->getPrice());
        self::$_db->execute();
        return self::$_db->lastInsertId();
    }

    //get a single keyboard
    static function getKeyboard(int $id){
        $sql = "SELECT * FROM keyboards WHERE id = :id";

        self::$_db->query($sql);
        self::$_db->bind(":id", $id);
        self::$_db->execute();
        return self::$_db->singleResult();
    }

}

?>