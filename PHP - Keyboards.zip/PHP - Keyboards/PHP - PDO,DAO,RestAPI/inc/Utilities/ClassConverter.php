<?php

class ClassConverter
{

    //pass in the data to be converted
    public static function convertToStdClass($data)
    {

        //store the retun objects
        $stdObjects = new stdClass;

        //if we get an array of data, respond with an array
        if (is_array($data)) {

            $stdObjects = array();

            //go through each element of the array and surface the data that is relevant
            foreach ($data as $keyboard) {

                //create a new blank object with the standard class definition
                $stdObject = new stdClass;

                //populate all the members
                $stdObject->id = $keyboard->getId();
                $stdObject->keyboardBase = $keyboard->getKeyboardBase();
                $stdObject->switchType = $keyboard->getSwitchType();
                $stdObject->actuationMechanism = $keyboard->getActuationMechanism();
                $stdObject->layout = $keyboard->getLayout();
                $stdObject->price = $keyboard->getPrice();

                //then add it to the array
                $stdObjects[] = $stdObject;
            }

        } else {
            //if not repsond with a single object
            //create a new blank object with the standard class definition
            $stdObjects = new stdClass;

            //populate all the members
            $stdObjects->id = $data->getid();
            $stdObjects->keyboardBase = $data->getKeyboardBase();
            $stdObjects->switchtype = $data->getSwitchType();
            $stdObjects->actuationMechanism = $data->getActuationMechanism();
            $stdObjects->layout = $data->getLayout();
            $stdObjects->price = $data->getPrice();
        }
        return $stdObjects;
    }

    static function convertToKeyboard($data){
        if(is_array($data)){
            $keyboards = array();
            foreach($data as $item){
                //create keyboards
                $nk = new Keyboard();
                $nk->setId($item->id);
                $nk->setKeyboardBase($item->keyboardBase);
                $nk->setswitchType($item->switchType);
                $nk->setactuation_mechanism($item->actuationMechanism);
                $nk->setlayout($item->layout);
                $nk->setprice($item->price);  //test this out
                // $nk->setprice(0);
                //store the keyboards
                $keyboards[] = $nk;
            }
        }
        return $keyboards;
    }

}
