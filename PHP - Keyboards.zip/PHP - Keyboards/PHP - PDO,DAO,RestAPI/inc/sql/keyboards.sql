-- http://140.161.86.41:8080/

DROP DATABASE IF EXISTS `week8`;

CREATE DATABASE week8;
USE week8;

create table keyboards (
	id int 	AUTO_INCREMENT PRIMARY KEY,
	keyboardBase VARCHAR(8),
	switchType VARCHAR(10),
	actuation_mechanism VARCHAR(7),
	layout VARCHAR(3),
	price DECIMAL(5,2)
);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'optical', 'tactile', 75, 119.57);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('Aluminum', 'Membrane', 'linear', 40, 81.1);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Membrane', 'linear', 60, 86.59);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'linear', 40, 279.13);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Membrane', 'tactile', 108, 156.77);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Membrane', 'tactile', 60, 243.42);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'optical', 'linear', 108, 214.14);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('Aluminum', 'Topre', 'linear', 60, 119.03);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('Aluminum', 'Mechanical', 'linear', 75, 213.37);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'linear', 40, 281.98);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('ABS', 'optical', 'clicky', 108, 219.32);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'optical', 'clicky', 40, 83.99);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Membrane', 'tactile', 68, 94.11);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('ABS', 'optical', 'tactile', 98, 150.47);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('ABS', 'Membrane', 'tactile', 108, 255.86);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('Aluminum', 'Membrane', 'clicky', 98, 290.92);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('Aluminum', 'Mechanical', 'tactile', 75, 247.52);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Mechanical', 'linear', 40, 93.72);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'tactile', 60, 132.68);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'tactile', 40, 74.23);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('ABS', 'Membrane', 'linear', 75, 177.58);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'clicky', 40, 238.19);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'linear', 75, 67.51);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('ABS', 'Membrane', 'tactile', 75, 103.95);
insert into keyboards (keyboardBase, switchType, actuation_mechanism, layout, price) values ('PBT', 'Topre', 'linear', 108, 68.27);
