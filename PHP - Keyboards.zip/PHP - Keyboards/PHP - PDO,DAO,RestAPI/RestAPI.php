<?php

require_once("inc/config.inc.php");
require_once("inc/Entities/Keyboard.class.php");
require_once("inc/Utilities/PDOService.class.php");
require_once("inc/Utilities/KeyboardDAO.class.php");
require_once("inc/Utilities/ClassConverter.php");

//initialize the dao
KeyboardDAO::initialize();

//read in the dara for the webservice
//read in the streamm data
$requestData = json_decode(file_get_contents('php://input'));

//default header
header('Content-Type: application/json');

//check what kind of request we got
switch($_SERVER["REQUEST_METHOD"]){
    case "GET":
        if(isset($requestData->id)){
            //get the specific keyboard

            //return the keyboard we want
            $nk = KeyboardDAO::getKeyboard($requestData->id);
            echo json_encode(ClassConverter::convertToStdClass($nk));
        } else{
            echo json_encode(ClassConverter::convertToStdClass(KeyboardDAO::getKeyboards()));
        }
        break;
    case "PUT":
        //do update things
        echo json_encode(array("message" => "do update stuff"));
        break;
    case "POST":
        //Do Insert things
        // echo json_encode(array("message" => "Do insert things"));
        //now assemble the keyboard


    $nk = new Keyboard();
    $nk->setKeyboardBase($requestData->keyboardBase);
    $nk->setswitchType($requestData->switchType);
    $nk->setactuation_mechanism($requestData->actuationMechanism);
    $nk->setlayout($requestData->layout);
    $nk->setprice($requestData->price);

    KeyboardDAO::addKeyboard($nk);

    
        break;
    case "DELETE":
        if(isset($requestData->id)){
            //delete the requested keyboard
            echo json_encode(array("result" => KeyboardDAO::deleteKeyboard($requestData->id)));
        } else{
            echo json_encode(array("message" => "You must specify a keyboard to delete."));
        }
        //de delete things
        break;
    default:
    echo json_encode(array("message" => " HTTP verb not good"));
        break;

}

?>