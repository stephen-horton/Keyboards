<?php

//require
require_once("inc/config.inc.php");
require_once("inc/Entities/Keyboard.class.php");
require_once("inc/Utilities/RestClient.inc.php");
require_once("inc/Utilities/Page.class.php");
require_once("inc/Utilities/ClassConverter.php");
require_once("inc/Utilities/Validation.class.php");
// require_once("inc/Utilities/KeyboardDAO.class.php");
// require_once("inc/Utilities/PDOService.class.php");

//processes

//process the delete
if(isset($_GET["action"]) && $_GET["action"] == "delete"){
    //call the restAPI to the delete the keyboard
    $deleteResult = RestClient::call("DELETE", array("id" =>$_GET["idToDelete"]));
    //encode the result
    $deleteRecordCount = json_decode($deleteResult);
}

//process the create
if(isset($_POST)){

    RestClient::call("POST",$_POST);

    //errors
    $errors = array();
    //validate the data
    $errors = Validation::validateAddKeyboard($_POST);
}


$jKeyboards = json_decode(RestClient::call("GET", array()));
$keyboards = ClassConverter::convertToKeyboard($jKeyboards);

Page::header();

//show the errors if any
if(!empty($errors)){
    Page::showValidationErrors(($errors));
} else{

    if(isset($_POST["action"]) && $_POST["action"] == "create"){
        Page::showWarning("Keyboard ID was added.");
        RestClient::call("POST",$_POST);

    }
}

if(isset($_GET["action"]) && $_GET["action"] == "delete"){
    //show the user a message
    Page::showWarning("keyboard ID" . $_GET["idToDelete"] . " was removed.");
}


Page::KeyboardForm();

Page::showKeyboards($keyboards);

Page::footer();
?>