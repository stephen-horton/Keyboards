<?php

require_once("inc/config.inc.php");
//entities
require_once("inc/Entities/Keyboard.class.php");
//utilitities
require_once("inc/Utilities/PDOService.class.php");
require_once("inc/Utilities/KeyboardDAO.class.php");
require_once("inc/Utilities/Page.class.php");

//initialize the dao
KeyboardDAO::initialize();

// +----+--------------+------------+---------------------+--------+--------+
// | id | keyboardBase | switchType | actuation_mechanism | layout | price  |
// +----+--------------+------------+---------------------+--------+--------+

//process the data
if(isset($_POST["action"]) && $_POST["action"] == "create"){
    //now assemble the keyboard
    $nk = new Keyboard();
    $nk->setKeyboardBase($_POST["keyboardBase"]);
    $nk->setswitchType($_POST["switchType"]);
    $nk->setactuation_mechanism($_POST["actuationMechanism"]);
    $nk->setlayout($_POST["layout"]);
    $nk->setprice((float)$_POST["price"]); 

    //then send it to the dao to be added
    $lastInsertedId = KeyboardDAO::addKeyboard($nk);
}

//process the delete
if(isset($_GET["action"]) && $_GET["action"] == "delete"){
    //delete the specified keyboard
    $deletedRecordcount = KeyboardDAO::deleteKeyboard($_GET["idToDelete"]);
}

$keyboards = KeyboardDAO::getKeyboards();

Page::header();

if(isset($_GET["action"]) && $_GET["action"] == "delete" ){
    Page::showWarning("Keyboard ID " . $_GET["idToDelete"] . " was deleted.");
}

if(isset($_POST["action"]) && $_POST["action"] == "create"){
    Page::showWarning("Keyboard ID " . $lastInsertedId . " was added.");
}

Page::KeyboardForm();

Page::showKeyboards($keyboards);


Page::footer();
?>